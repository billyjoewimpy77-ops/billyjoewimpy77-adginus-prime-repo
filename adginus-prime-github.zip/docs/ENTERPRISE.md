# Enterprise - FEC HARD GATE

$999 one-time.

Blocks:
- [PENDING] placeholder
- Missing committee ID (format C + 8 digits)
- Missing disclaimer "Paid for by..."
- Missing address

Audit chain exportable for FEC.
