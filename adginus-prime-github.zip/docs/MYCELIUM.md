# Mycelium Organizer

Reads Gmail, Messenger, X via NotificationListenerService (Android) or via API in this repo.

Frontend Mycelium page shows drafts.

Backend: SharedMemoryBus.
