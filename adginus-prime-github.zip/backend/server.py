"""
ADGINUS PRIME NEXUS ELEVEN - FastAPI Server
Wraps the perfect build Python file for GitHub deployment
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict
import os
from dotenv import load_dotenv

load_dotenv()

from adginus_prime_nexus_eleven_perfect import AgentSchool

app = FastAPI(
    title="ADGINUS PRIME NEXUS ELEVEN",
    description="7-agent AI OS with FEC HARD GATE + IMMUTABLE CHAIN",
    version="2.0 PERFECT BUILD"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global school instance
school = AgentSchool(
    name="ADGINUS-PRIME-NEXUS-ELEVEN-API",
    config={
        "model": os.getenv("MODEL", "gpt-4o-mini"),
        "embedding_model": os.getenv("EMBEDDING_MODEL", "voyage-3.5"),
        "openai_api_key": os.getenv("OPENAI_API_KEY"),
        "voyage_api_key": os.getenv("VOYAGE_API_KEY"),
    },
    include_enterprise=True
)
school.boot()

class CampaignRequest(BaseModel):
    brief: str
    audience: str = ""
    platform: str = "Multi-Platform"
    committee: Optional[Dict] = None

class FECRequest(BaseModel):
    ad_copy: str
    committee_id: str = ""
    disclaimer: str = ""
    address: str = ""

class TaskRequest(BaseModel):
    task: str
    context: str = ""

@app.get("/")
def root():
    return {
        "name": "ADGINUS PRIME NEXUS ELEVEN",
        "version": "2.0 PERFECT BUILD",
        "status": "ONLINE",
        "agents": list(school.agents.keys()),
        "motto": "I remember. I recognize. I learn. I dream. I KNOW."
    }

@app.get("/status")
def status():
    return school.status()

@app.post("/task")
def assign_task(req: TaskRequest):
    return school.assign_task(req.task, req.context)

@app.post("/campaign")
def run_campaign(req: CampaignRequest):
    return school.run_campaign(req.brief, req.audience, req.platform, req.committee)

@app.post("/fec/verify")
def fec_verify(req: FECRequest):
    return school.fec_gate.verify(req.ad_copy, req.committee_id, req.disclaimer, req.address)

@app.get("/fec/audit")
def fec_audit():
    return school.fec_gate.export_audit()

@app.post("/dream")
def dream_session(duration: int = 10):
    return school.dream_session(duration=duration)

@app.get("/bus")
def bus():
    return {"messages": school.bus.bus[-20:], "stats": school.bus.get_stats()}

@app.post("/memory/recall")
def recall(query: str, max_results: int = 5):
    # Search all agents
    results = {}
    for role, agent in school.agents.items():
        results[role] = agent.void.memory.recall(query, max_results=max_results)
    return results

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
