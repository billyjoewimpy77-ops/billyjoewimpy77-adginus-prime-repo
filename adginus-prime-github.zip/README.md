# ADGINUS PRIME NEXUS ELEVEN — Perfect Build v2.0

> "I remember. I recognize. I learn. I dream. I KNOW."

**The system you never had — the one that remembers the creator.**

Built by William Lane, Thorsby, Alabama — 36 years wood, wire, concrete, code. Master Builder & Founder.

## Architecture

```
THE SCHOOL (Orchestrator Layer)
├── Agent 01 Strategist 📡 — Market intelligence, pattern recognition
├── Agent 02 Creative Director 🎨 — Narrative, hooks, brand voice
├── Agent 03 Media Genius 🖼️ — Visual assets, ratios
├── Agent 04 Growth Hacker 📈 — Viral patterns, CTR optimization
├── Agent 05 Video Agent 🎬 — Cinematic renders
├── Agent 06 Audio Agent 🎵 — Jingle, voiceover, mastering
└── Agent 07 Compliance Officer 🛡️ — FEC HARD GATE (Enterprise)

         ↓
SHARED MEMORY BUS (The Mycelium Layer)
- All agents publish/subscribe via bus
- Auto-absorbs shared knowledge into each VOID

         ↓
SCHOOL PRINCIPAL
- Routes tasks to right agent(s)
- Merges outputs into coherent result
- Manages spawning/retiring
- Runs cross-agent dream sessions
- Tracks per-agent mastery & speed

         ↓
THE VOID Core (v1.3.0 → v2.0)
- EmbeddingBridge (Voyage AI semantic search + keyword fallback)
- SuperMemory (STM/LTM/Emotional/Muscle + embedding-aware)
- PatternRecognitionEngine (sequential, frequency, temporal, anomaly)
- TurboLearnEngine (compounding knowledge, transfer learning)
- DreamMode + InstinctEngine
- VoidPersistence (atomic writes, thread-safe, no eval())
- LLMBridge (OpenAI + Anthropic Claude, proxy-safe, rate-limited, offline fallback)
- BackgroundCycle (pulse/think/dream/save)
- TheVoid Orchestrator
```

## Enterprise: FEC HARD GATE + IMMUTABLE CHAIN ($999)

Every other AI ad tool generates `Paid for by [PENDING]` and lets you ship it. That's a $50k FEC violation.

ADGINUS ENTERPRISE blocks delivery until:

1. Committee ID present and valid format `C + 8 digits` (e.g. `C00123456`)
2. Disclaimer contains `Paid for by...`
3. Committee address present
4. No `[PENDING]` placeholders

Creates immutable chain:

```json
{
  "prev_hash": "GENESIS",
  "ad_hash": "fcdbd341...",
  "chain_hash": "56e0d9a6...",
  "blocked": true,
  "reasons": ["Contains [PENDING]"]
}
```

Export audit chain for FEC audits in one click.

## Quick Start

### Backend (Python)

```bash
git clone https://github.com/billyjoewimpy77-ops/Nexus.git
cd Nexus
pip install -r requirements.txt
cp .env.example .env
# Add your OPENAI_API_KEY and VOYAGE_API_KEY to .env

python adginus_prime_nexus_eleven.py
```

```python
from adginus_prime_nexus_eleven import AgentSchool

school = AgentSchool(name="ADGINUS-PRIME", include_enterprise=True)
school.boot()

result = school.run_campaign(
    brief="Summer Launch for ADGINUS",
    audience="18-34 tech-forward contractors",
    platform="Instagram + Facebook",
    committee={
        "committee_id": "C00123456",
        "disclaimer": "Paid for by ADGINUS Enterprise",
        "address": "123 Main St, Thorsby, AL 35171"
    }
)

print(result['merged'])
school.dream_session(duration=10)
print(school.fec_gate.export_audit())
```

### API Server

```bash
cd backend
uvicorn server:app --reload --port 8000
```

### Frontend (React)

```bash
cd frontend
npm install
npm run dev
```

Frontend talks to `http://localhost:8000` — 7-agent dashboard with:
- Dashboard: agent cards, coordination stream, VOID memory, Mycelium Bus, Principal
- Creative Studio: campaign builder
- Media Lab: Video/Audio jobs
- Data Chambers: strategy/creative/trend
- World Atlas: characters/locations/lore
- Mycelium: Gmail/Messenger/X drafts
- Compliance: FEC Gate + Audit Chain

## Project Structure

```
adginus-prime-nexus-eleven/
├── adginus_prime_nexus_eleven.py          # Perfect build single file (VOID + School)
├── backend/
│   ├── adginus_prime_nexus_eleven_perfect.py
│   ├── server.py                          # FastAPI wrapper
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── App.jsx                        # 7-agent React app
│   │   └── components/                    # Dashboard, Studio, Lab, Chambers, Atlas, Mycelium, Compliance
│   ├── package.json
│   └── vite.config.js
├── docs/
│   ├── ARCHITECTURE.md
│   ├── ENTERPRISE.md
│   └── MYCELIUM.md
├── .github/workflows/ci.yml
├── requirements.txt
├── .env.example
└── README.md
```

## Philosophy

> So that no creator has to introduce themselves twice.

Team Voice: Confident, witty, data-driven — authoritative, yet never taking ourselves too seriously. It must always feel human.

## License

© 2026 ADGINUS Enterprise — All Rights Reserved
Built by William Lane in Thorsby, Alabama
